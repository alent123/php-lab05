
<?php
/*
Nombre: [santiago agustin salas perez]
Fecha: 18/04/2025
*/
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $cantidad = $_POST["cantidad"];
    $tipo = $_POST["tipo"];
    $tamano = $_POST["tamano"];
    $precio = $_POST["precio"];
    $ajuste = 0;

    if ($tipo == "A") {
        $ajuste = ($tamano == 1) ? 0.20 : 0.30;
    } elseif ($tipo == "B") {
        $ajuste = ($tamano == 1) ? -0.30 : -0.50;
    }

    $precioFinal = $precio + $ajuste;
    $ganancia = $cantidad * $precioFinal;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Resultado – Asociación de Vinicultores</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container mt-5">
    <h2 class="text-center text-primary mb-4">Resultado – Asociación de Vinicultores</h2>
    <div class="card p-4 shadow">
      <p><strong>Cantidad (kg):</strong> <?php echo htmlspecialchars($cantidad); ?></p>
      <p><strong>Tipo de uva:</strong> <?php echo "Tipo " . htmlspecialchars($tipo); ?></p>
      <p><strong>Tamaño:</strong> <?php echo "Tamaño " . htmlspecialchars($tamano); ?></p>
      <p><strong>Precio final por kg:</strong> S/ <?php echo number_format($precioFinal, 2); ?></p>
      <p class="text-success"><strong>Ganancia total:</strong> S/ <?php echo number_format($ganancia, 2); ?></p>
    </div>
  </div>
</body>
</html>
