<?php
/*
Nombre: [santiago agustin salas perez]
Fecha: 18/04/2025
*/

function generarTrianguloPascal($n) {
    $triangulo = [];

    for ($i = 0; $i < $n; $i++) {
        $triangulo[$i] = [];
        for ($j = 0; $j <= $i; $j++) {
            if ($j == 0 || $j == $i) {
                $triangulo[$i][$j] = 1;
            } else {
                $triangulo[$i][$j] = $triangulo[$i - 1][$j - 1] + $triangulo[$i - 1][$j];
            }
        }
    }

    return $triangulo;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $filas = $_POST["filas"];
    $resultado = generarTrianguloPascal($filas);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Resultado – Triángulo de Pascal</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .center-text { text-align: center; font-family: monospace; }
  </style>
</head>
<body class="bg-light">
  <div class="container mt-5">
    <h2 class="text-center text-primary mb-4">Resultado – Triángulo de Pascal</h2>
    <div class="card p-4 shadow center-text">
      <?php
      foreach ($resultado as $fila) {
          echo str_repeat("&nbsp;", 50 - count($fila) * 2);
          foreach ($fila as $num) {
              echo $num . "&nbsp;&nbsp;";
          }
          echo "<br>";
      }
      ?>
    </div>
  </div>
</body>
</html>
