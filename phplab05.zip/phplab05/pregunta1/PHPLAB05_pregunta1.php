<?php
/*
Nombre: [santiago agustin salas perez]
Fecha: 18/04/2025
*/

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $a = $_POST["a"];
    $b = $_POST["b"];
    $c = $_POST["c"];
    
    $p = ($a + $b + $c) / 2;
    $area = sqrt($p * ($p - $a) * ($p - $b) * ($p - $c));
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Resultado – Área del Triángulo</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container mt-5">
    <h2 class="text-center text-primary mb-4">Resultado – Área del Triángulo</h2>
    <div class="card p-4 shadow">
      <p><strong>Lado a:</strong> <?php echo $a; ?></p>
      <p><strong>Lado b:</strong> <?php echo $b; ?></p>
      <p><strong>Lado c:</strong> <?php echo $c; ?></p>
      <p class="text-success"><strong>Área calculada:</strong> <?php echo number_format($area, 2); ?></p>
    </div>
  </div>
</body>
</html>
